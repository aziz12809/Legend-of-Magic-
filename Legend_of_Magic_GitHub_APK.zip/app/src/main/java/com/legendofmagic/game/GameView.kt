package com.legendofmagic.game

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var heroX = 500f
    private var heroY = 360f
    private var hp = 100
    private var coins = 0
    private var attackUntil = 0L
    private var lastAttack = 0L
    private val monsters = mutableListOf(
        floatArrayOf(820f, 250f, 40f),
        floatArrayOf(1050f, 560f, 40f),
        floatArrayOf(720f, 620f, 40f)
    )

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()

        p.color = Color.rgb(35, 95, 55); c.drawRect(0f,0f,w,h,p)
        p.color = Color.rgb(52,125,68)
        for (x in 0..(w.toInt() step 90)) for (y in 0..(h.toInt() step 90))
            c.drawCircle(x.toFloat(), y.toFloat(), 28f, p)

        // village
        p.color = Color.rgb(130,82,48)
        c.drawRect(70f,80f,300f,230f,p)
        p.color = Color.rgb(170,45,45)
        val roof = Path(); roof.moveTo(45f,80f); roof.lineTo(185f,10f); roof.lineTo(325f,80f); roof.close()
        c.drawPath(roof,p)
        p.color = Color.WHITE; p.textSize=28f
        c.drawText("Деревня",95f,270f,p)

        // cave
        p.color = Color.rgb(30,30,38); c.drawCircle(w-140f,h-100f,90f,p)
        p.color = Color.WHITE; p.textSize=24f; c.drawText("Пещера",w-205f,h-190f,p)

        // monsters
        for (m in monsters) {
            p.color = Color.rgb(105,35,125); c.drawCircle(m[0],m[1],m[2],p)
            p.color = Color.BLACK; c.drawCircle(m[0]-12,m[1]-7,5f,p); c.drawCircle(m[0]+12,m[1]-7,5f,p)
        }

        // hero
        p.color = Color.rgb(70,100,220); c.drawCircle(heroX,heroY,34f,p)
        p.color = Color.rgb(245,210,170); c.drawCircle(heroX,heroY-42,20f,p)
        p.color = Color.LTGRAY
        c.drawRect(heroX+22,heroY-15,heroX+82,heroY-7,p)

        // UI
        p.color = Color.argb(180,0,0,0); c.drawRoundRect(18f,18f,330f,105f,20f,20f,p)
        p.color = Color.RED; c.drawRect(38f,42f,38f+2.4f*hp,60f,p)
        p.color = Color.WHITE; p.textSize=22f
        c.drawText("HP $hp/100",40f,35f,p)
        c.drawText("🪙 $coins",40f,92f,p)

        // controls
        p.color=Color.argb(150,255,255,255)
        c.drawCircle(100f,h-100f,55f,p)
        c.drawCircle(220f,h-100f,55f,p)
        c.drawCircle(w-100f,h-100f,65f,p)
        p.color=Color.DKGRAY; p.textSize=34f
        c.drawText("←",75f,h-88f,p); c.drawText("→",195f,h-88f,p); c.drawText("⚔",w-120f,h-88f,p)

        if (System.currentTimeMillis() < attackUntil) {
            p.color=Color.YELLOW; p.style=Paint.Style.STROKE; p.strokeWidth=10f
            c.drawCircle(heroX,heroY,75f,p); p.style=Paint.Style.FILL
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN && e.action != MotionEvent.ACTION_MOVE) return true
        val x=e.x; val y=e.y; val h=height.toFloat(); val w=width.toFloat()
        if (y > h-180 && x < 180) heroX -= 18
        else if (y > h-180 && x < 310) heroX += 18
        else if (y > h-180 && x > w-190) attack()
        heroX = heroX.coerceIn(40f,w-40f); heroY=heroY.coerceIn(80f,h-40f)
        return true
    }

    private fun attack() {
        val now=System.currentTimeMillis()
        if (now-lastAttack < 450) return
        lastAttack=now; attackUntil=now+180
        val it=monsters.iterator()
        while(it.hasNext()) {
            val m=it.next()
            if (hypot(m[0]-heroX,m[1]-heroY) < 130) {
                it.remove(); coins += 10
            }
        }
    }
}
